/**
 * 
 */
/**
 * 
 */
module PracticeJava {
	 exports com.example;
}