package com.example;

import java.util.Scanner;

public class Armstrong {
	public static void main(String[] args) {
//		1*1*1+5*5*5+3*3*3=153
		
//		int n=1543;
		Scanner s = new Scanner(System.in);
		System.out.print("Enter number : ");
		int n = s.nextInt();
		int sum=0;
		int p=n;
		while(n>0)
		{	
			int t=n%10;
			sum = sum +(t*t*t);
			n=n/10;
		}
		if(p==sum) {
			System.out.println(p +" is an Armstrong number ");
		}
		else {
			System.out.println(p +" is not an Armstrong number ");
		}
	}
}
