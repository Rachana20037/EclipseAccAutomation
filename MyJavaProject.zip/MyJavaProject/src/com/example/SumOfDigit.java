package com.example;

public class SumOfDigit {
	public static void main(String[] args) {
		int n = 123;
		int sum =0;
		while(n>0)
		{
			int t = n%10;
			sum = sum + t;
			n=n/10;
		}
		System.out.println(sum);
	}
}
