package com.example;

public class ReverseNumberString {
	public static void main(String[] args) {
   
		String name = "rachana";
		String reverse ="";
		for(int i=name.length()-1;i>=0;i--)
		{
			reverse =reverse + name.charAt(i);
		}
		System.out.println(reverse);
		
		/*
		int num=1234354645;

		while(num>0)
		{
			int a = num%10;
			System.out.print(a);
			num=num/10;
		}
		 */
		
	}
}
