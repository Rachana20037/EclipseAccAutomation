package com.example;

public class StarPattern {
	public static void main(String[] args) {
	/*
		int k=1;
		for(int i=0;i<5;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print(k+ " ");
				k++;
			}
			System.out.println(" ");
		}
		
		1  
		2 3  
		4 5 6  
		7 8 9 10  
		11 12 13 14 15  
*/
	/*	
		for(int i=0;i<=5;i++)
		{
			for(int j=0;j<=i;j++)
			{
				System.out.print("* ");
			}
			System.out.println("");
		}
		
		* 
		* * 
		* * * 
		* * * * 
		* * * * * 
		* * * * * * 
		
	*/	
		
	/*
		for(int i=0;i<=5;i++)
		{
			for(int j=5; j>=i;j--)
			{
				System.out.print("*");
			}
			System.out.println("");
		}
		******
		*****
		****
		***
		**
		*
	*/
	/*	
		int n=4;
		for(int i=1;i<=n;i++)
		{
			for(int j=1; j>i;j--)
			{
				System.out.print(" ");
			}
			
			for(int k=1;k<=i;k++)
			{
				System.out.print("*");
			}
			System.out.println("");
		}
		*/
/*		
		int rows = 4; // Number of rows

        for (int i = 0; i <= rows; i++) {
            for (int j = rows; j > i; j--) {
                System.out.print("  ");
            }
            for (int k = 0; k <= i; k++) {
                System.out.print("* ");
            }
            System.out.println();
        }
        
        * 
      * * 
    * * * 
  * * * * 
* * * * * 

*/	
		/*
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=i;j++)
			{
				System.out.print(j);	
			}
			System.out.println("");
		}
		
		1
		12
		123
		1234
		12345
		
		*/
		for(int i=1;i<=5;i++)
		{
			for(int j=1;j<=5-i+1;j++)
			{
				System.out.print(j);
			}
			System.out.println("");
		}
		
		
		
		
		
		
		
		
		
		
		
		
	}
}
