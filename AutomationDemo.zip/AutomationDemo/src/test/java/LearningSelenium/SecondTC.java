package LearningSelenium;

import org.testng.annotations.Test;

public class SecondTC {

	@Test
	public void testMethod1() {
		System.out.println("method 1");
	}
	
	@Test
	public void testMethod2() {
		System.out.println("method 2");
	}
	
	@Test
	public void testMethod3() {
		System.out.println("method 3");
	}
}
