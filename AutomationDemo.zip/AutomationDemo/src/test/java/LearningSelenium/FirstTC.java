package LearningSelenium;

import org.testng.annotations.Test;

public class FirstTC {
	@Test
	void setup() 
	{
		System.out.println("setUp here");
	}
	
	@Test
	void login()
	{
		
	}
	
	@Test
	void close()
	{
		
	}
}
