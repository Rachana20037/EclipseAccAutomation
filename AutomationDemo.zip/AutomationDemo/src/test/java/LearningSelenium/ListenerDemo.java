package LearningSelenium;

import org.testng.annotations.Test;
import org.testng.AssertJUnit;
import org.testng.SkipException;
import org.openqa.selenium.By;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

public class ListenerDemo {
	@Test
	public void login() throws InterruptedException
	{
		WebDriver ww = new ChromeDriver();
		ww.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		ww.manage().window().maximize();
		Thread.sleep(5000);
		ww.findElement(By.name("username")).sendKeys("Admin");
		ww.findElement(By.name("password")).sendKeys("admin123");
		ww.findElement(By.xpath("//button[.=' Login ']")).click();
		AssertJUnit.assertEquals(ww.getTitle(), "OrangeHRM");
	}
	
	@Test
	public void testFail() 
	{
		System.out.println("TC will fail");
		AssertJUnit.assertTrue(false);
	}
	
	@Test
	public void testSkipped() 
	{
		System.out.println("TC will Skipped");
		throw new SkipException("Skip TC ");
	}
}
