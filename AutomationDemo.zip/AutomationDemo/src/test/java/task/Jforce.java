package task;

import java.awt.Desktop.Action;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class Jforce {
	public static void add(){
		System.out.println("hello");
	}
	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.fitpeo.com/");
		driver.manage().window().maximize();
		
		//Click on Revenue Calculator
		driver.findElement(By.linkText("Revenue Calculator")).click();
		Thread.sleep(2000);
		
		// Scroll Down 
		JavascriptExecutor j =(JavascriptExecutor)driver;
		j.executeScript("window.scrollBy(0,500)");
		
		Thread.sleep(5000);
		
		//slider value to 600
		WebElement slide = driver.findElement(By.cssSelector(".MuiSlider-thumb.MuiSlider-thumbSizeMedium.MuiSlider-thumbColorPrimary.MuiSlider-thumb.MuiSlider-thumbSizeMedium.MuiSlider-thumbColorPrimary.css-1sfugkh"));
		Actions a = new Actions(driver);
		a.moveToElement(slide).click().perform();
		a.dragAndDropBy(slide, 61, 0).perform();
		
		Thread.sleep(3000);
		
		//set 560 slider value 
		driver.findElement(By.xpath("//input[@type='number']")).clear();
		driver.findElement(By.xpath("//input[@type='number']")).sendKeys("560");
		
		
			
		//checkbox select 
		j.executeScript("window.scrollBy(0,2000)");
		driver.findElement(By.xpath("//span[.='41']")).click();
		driver.findElement(By.xpath("//span[.='37']")).click();
		
		j.executeScript("window.scrollBy(0,100)");
		driver.findElement(By.xpath("//span[.='92']")).click();
		driver.findElement(By.xpath("//span[.='46']")).click();
		
		//Get Text
		WebElement num =driver.findElement(By.xpath("//p[text()='Total Recurring Reimbursement for all Patients Per Month:']"));
		System.out.println(num.getText());
		
		driver.close();		
		add();
		
	}
}


/*
		int scroll = driver.findElement(By.xpath("//span[@style='left: 30.8%;']")).getLocation().getY();
		JavascriptExecutor j =(JavascriptExecutor)driver;
		j.executeScript("window.scrollBy(0,500)");
		j.executeScript("window.scrollBy(0,"+scroll+")");

*/